package com.qhit.lh.shutu.exam.common.utils;

public class Constans {
	public static final String VIEW_LOGIN = "login_view";

}
