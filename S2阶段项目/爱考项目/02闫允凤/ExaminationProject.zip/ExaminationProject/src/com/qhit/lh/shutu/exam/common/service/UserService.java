package com.qhit.lh.shutu.exam.common.service;

import com.qhit.lh.shutu.exam.common.been.User;


public interface UserService {

	public User login(User user);
}
