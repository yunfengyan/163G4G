package com.qhit.lh.shutu.exam.common.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.qhit.lh.shutu.exam.common.utils.HibernateSessionFactory;


public class BaseDao {

	public Session getSession(){
		return HibernateSessionFactory.getSession();
	}
}
