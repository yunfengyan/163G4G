package com.qhit.lh.shutu.exam.common.dao;

import com.qhit.lh.shutu.exam.common.been.User;


public interface UserDao {

	public User login(User user);
}
