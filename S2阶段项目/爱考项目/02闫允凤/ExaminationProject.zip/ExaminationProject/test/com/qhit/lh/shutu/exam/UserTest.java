package com.qhit.lh.shutu.exam;

import org.junit.Test;

import com.qhit.lh.shutu.exam.common.acction.UserAction;
import com.qhit.lh.shutu.exam.common.been.User;

public class UserTest {

	@Test
	public void login(){
		UserAction userAction = new UserAction();
		
		User user = new User();
		user.setName("admin");
		user.setPwd("123456");
		user.setRole(4);
		
		userAction.setUser(user);
		
		System.out.println(userAction.login());;
		
	}
}
